package io.github.warleysr.dechainer.data

import android.app.AlarmManager
import android.app.PendingIntent
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import androidx.core.content.edit
import io.github.warleysr.dechainer.DechainerDeviceAdminReceiver
import io.github.warleysr.dechainer.notifications.SleepModeReceiver
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId

/**
 * Scheduled daily sleep block. Blacklist always wins. When whitelist enforcement is enabled,
 * every installed app not on the whitelist is blocked; the blacklist still wins on overlap.
 */
object SleepMode {
    const val PREFS = "sleep_mode_prefs"
    private const val KEY_ENABLED = "enabled"
    private const val KEY_START = "start_minute"
    private const val KEY_END = "end_minute"
    private const val KEY_WHITELIST_ENABLED = "whitelist_enabled"
    private const val KEY_WHITELIST = "whitelist"
    private const val KEY_BLACKLIST = "blacklist"
    private const val KEY_ACTIVE = "active_packages"
    const val ACTION_SYNC = "io.github.warleysr.dechainer.sleep.SYNC"

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun isEnabled(context: Context) = prefs(context).getBoolean(KEY_ENABLED, false)
    fun setEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit { putBoolean(KEY_ENABLED, enabled) }
        sync(context)
    }
    fun startMinute(context: Context) = prefs(context).getInt(KEY_START, 22 * 60)
    fun endMinute(context: Context) = prefs(context).getInt(KEY_END, 7 * 60)
    fun setTimes(context: Context, start: Int, end: Int) {
        prefs(context).edit {
            putInt(KEY_START, start.coerceIn(0, 1439))
            putInt(KEY_END, end.coerceIn(0, 1439))
        }
        sync(context)
    }
    fun isWhitelistEnabled(context: Context) = prefs(context).getBoolean(KEY_WHITELIST_ENABLED, true)
    fun setWhitelistEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit { putBoolean(KEY_WHITELIST_ENABLED, enabled) }
        sync(context)
    }
    fun whitelist(context: Context): Set<String> =
        prefs(context).getStringSet(KEY_WHITELIST, emptySet())?.toSet() ?: emptySet()
    fun blacklist(context: Context): Set<String> =
        prefs(context).getStringSet(KEY_BLACKLIST, emptySet())?.toSet() ?: emptySet()

    fun setWhitelisted(context: Context, pkg: String, selected: Boolean) {
        val updated = whitelist(context).toMutableSet().apply {
            if (selected) add(pkg) else remove(pkg)
        }
        prefs(context).edit { putStringSet(KEY_WHITELIST, updated) }
        sync(context)
    }
    fun setBlacklisted(context: Context, pkg: String, selected: Boolean) {
        val updated = blacklist(context).toMutableSet().apply {
            if (selected) add(pkg) else remove(pkg)
        }
        prefs(context).edit { putStringSet(KEY_BLACKLIST, updated) }
        sync(context)
    }

    fun isActiveAt(context: Context, time: LocalTime = LocalTime.now()): Boolean {
        if (!isEnabled(context)) return false
        val start = startMinute(context)
        val end = endMinute(context)
        val now = time.hour * 60 + time.minute
        if (start == end) return false
        return if (start < end) now >= start && now < end else now >= start || now < end
    }

    fun isHolding(context: Context, pkg: String): Boolean =
        pkg in (prefs(context).getStringSet(KEY_ACTIVE, emptySet()) ?: emptySet())

    /** Applies the current state, then schedules the next start/end boundary. Safe to call repeatedly. */
    @Synchronized
    fun sync(context: Context) {
        val appContext = context.applicationContext
        val p = prefs(appContext)
        val previous = p.getStringSet(KEY_ACTIVE, emptySet())?.toSet() ?: emptySet()
        val active = isActiveAt(appContext)
        val targets = if (!active) emptySet() else {
            val white = whitelist(appContext)
            val black = blacklist(appContext)
            val enforceWhitelist = isWhitelistEnabled(appContext)
            val installed = try {
                appContext.packageManager.getInstalledApplications(0)
                    .map { it.packageName }
                    .filter { it != appContext.packageName }
                    .toSet()
            } catch (_: Exception) { emptySet() }
            installed.filterTo(mutableSetOf()) { pkg ->
                pkg in black || (enforceWhitelist && pkg !in white)
            }
        }

        val dpm = appContext.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val admin = ComponentName(appContext, DechainerDeviceAdminReceiver::class.java)
        if (dpm.isAdminActive(admin)) {
            val dropped = previous - targets
            val releasable = dropped.filterNot { heldByAnotherMode(appContext, it) }
            if (releasable.isNotEmpty()) {
                try { dpm.setPackagesSuspended(admin, releasable.toTypedArray(), false) }
                catch (_: Exception) { /* Keep other active restrictions intact if the OS rejects a release. */ }
            }

            val failed = if (targets.isEmpty()) emptyArray() else try {
                dpm.setPackagesSuspended(admin, targets.toTypedArray(), true)
            } catch (_: Exception) { targets.toTypedArray() }
            val successfullyClaimed = (targets - failed.toSet()) + (previous intersect targets)
            p.edit { putStringSet(KEY_ACTIVE, successfullyClaimed) }
        } else {
            // Keep the last claims if privileges temporarily disappear; forgetting them could
            // leave a package suspended with no owner to release it later.
        }

        scheduleNextBoundary(appContext)
    }

    private fun heldByAnotherMode(context: Context, pkg: String): Boolean =
        FocusMode.isHolding(context, pkg) ||
            pkg in SecurityManagerCompat.activeImpulse(context) ||
            VisualBlockingSuspensionTracker(context).isSuspended(pkg)

    private fun scheduleNextBoundary(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, SleepModeReceiver::class.java).setAction(ACTION_SYNC)
        val pending = PendingIntent.getBroadcast(
            context, 701, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.cancel(pending)
        if (!isEnabled(context)) return

        val now = LocalDateTime.now()
        val zone = ZoneId.systemDefault()
        val candidates = (-1L..2L).flatMap { offset ->
            val date = LocalDate.now().plusDays(offset)
            listOf(startMinute(context), endMinute(context)).map { minute ->
                date.atTime(minute / 60, minute % 60).atZone(zone).toInstant().toEpochMilli()
            }
        }.filter { it > System.currentTimeMillis() }
        val next = candidates.minOrNull() ?: now.plusDays(1).atZone(zone).toInstant().toEpochMilli()
        alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next, pending)
    }
}

/** Small indirection keeps the sleep manager from owning impulse-mode implementation details. */
private object SecurityManagerCompat {
    fun activeImpulse(context: Context): Set<String> =
        io.github.warleysr.dechainer.security.SecurityManager.getActiveImpulseSuspension(context)
}
