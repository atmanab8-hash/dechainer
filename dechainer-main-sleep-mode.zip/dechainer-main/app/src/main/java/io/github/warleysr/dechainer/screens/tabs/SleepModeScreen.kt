package io.github.warleysr.dechainer.screens.tabs

import android.app.TimePickerDialog
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Bedtime
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.foundation.Image
import io.github.warleysr.dechainer.data.AppRepository
import io.github.warleysr.dechainer.data.SleepMode
import io.github.warleysr.dechainer.models.AppItem
import io.github.warleysr.dechainer.screens.common.RecoveryGateDialog
import io.github.warleysr.dechainer.screens.common.rememberRecoveryGate
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.LocalTime

@Composable
fun SleepModeScreen() {
    val context = LocalContext.current
    val gate = rememberRecoveryGate()
    var enabled by remember { mutableStateOf(SleepMode.isEnabled(context)) }
    var whitelistMode by remember { mutableStateOf(SleepMode.isWhitelistEnabled(context)) }
    var startMinute by remember { mutableIntStateOf(SleepMode.startMinute(context)) }
    var endMinute by remember { mutableIntStateOf(SleepMode.endMinute(context)) }
    val white = remember { mutableStateListOf<String>().apply { addAll(SleepMode.whitelist(context)) } }
    val black = remember { mutableStateListOf<String>().apply { addAll(SleepMode.blacklist(context)) } }
    var apps by remember { mutableStateOf<List<AppItem>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var selectedList by remember { mutableIntStateOf(0) }
    var query by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        apps = withContext(Dispatchers.IO) { AppRepository.getApps(forceRefresh = true) }
        loading = false
    }

    fun runProtected(action: () -> Unit) {
        if (SleepMode.isActiveAt(context)) gate.run(action = action) else action()
    }

    fun setTime(isStart: Boolean, hour: Int, minute: Int) {
        runProtected {
            val value = hour * 60 + minute
            if (isStart) startMinute = value else endMinute = value
            SleepMode.setTimes(context, startMinute, endMinute)
            enabled = SleepMode.isEnabled(context)
        }
    }

    val filteredApps = remember(apps, query) {
        apps.filter {
            it.packageName != context.packageName &&
                (it.name.contains(query, true) || it.packageName.contains(query, true))
        }
    }

    Scaffold { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Outlined.Bedtime, contentDescription = null)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("وضع النوم", style = MaterialTheme.typography.titleLarge)
                        Text("حظر التطبيقات تلقائيًا خلال الوقت المحدد", style = MaterialTheme.typography.bodyMedium)
                    }
                    Switch(checked = enabled, onCheckedChange = { value ->
                        runProtected { SleepMode.setEnabled(context, value); enabled = value }
                    })
                }
                HorizontalDivider()
            }
            item {
                Text("الجدول اليومي", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 16.dp, bottom = 8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    TimeButton("وقت النوم", startMinute, Modifier.weight(1f)) { h, m -> setTime(true, h, m) }
                    TimeButton("وقت الاستيقاظ", endMinute, Modifier.weight(1f)) { h, m -> setTime(false, h, m) }
                }
                Text(
                    "إذا كان وقت النوم بعد منتصف الليل، فسيستمر الحظر حتى وقت الاستيقاظ في اليوم التالي.",
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(top = 8.dp, bottom = 16.dp)
                )
                HorizontalDivider()
            }
            item {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp)) {
                    Column(Modifier.weight(1f)) {
                        Text("فرض القائمة البيضاء", style = MaterialTheme.typography.titleMedium)
                        Text("عند التفعيل، تُحظر التطبيقات غير الموجودة في البيضاء؛ والسوداء لها الأولوية دائمًا.", style = MaterialTheme.typography.bodySmall)
                    }
                    Switch(checked = whitelistMode, onCheckedChange = { value ->
                        runProtected { SleepMode.setWhitelistEnabled(context, value); whitelistMode = value }
                    })
                }
                OutlinedTextField(
                    value = query, onValueChange = { query = it },
                    label = { Text("بحث عن تطبيق") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                TabRow(selectedTabIndex = selectedList) {
                    Tab(selected = selectedList == 0, onClick = { selectedList = 0 }, text = { Text("البيضاء (${white.size})") })
                    Tab(selected = selectedList == 1, onClick = { selectedList = 1 }, text = { Text("السوداء (${black.size})") })
                }
                Text(
                    if (selectedList == 0) "هذه التطبيقات مسموحة فقط إذا لم تكن في القائمة السوداء."
                    else "هذه التطبيقات محظورة حتى لو كانت في القائمة البيضاء.",
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(vertical = 8.dp)
                )
                if (whitelistMode && white.isEmpty()) {
                    Text(
                        "تنبيه: القائمة البيضاء فارغة؛ عند بدء النوم سيُحظر كل تطبيق قابل للتعليق حتى تضيفه إلى البيضاء.",
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                }
            }
            if (loading) {
                item { Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() } }
            } else {
                items(filteredApps, key = { it.packageName }) { app ->
                    val selected = if (selectedList == 0) app.packageName in white else app.packageName in black
                    ListItem(
                        leadingContent = { Image(app.icon.toBitmap().asImageBitmap(), contentDescription = null, modifier = Modifier.size(40.dp)) },
                        headlineContent = { Text(app.name) },
                        supportingContent = { Text(app.packageName, style = MaterialTheme.typography.bodySmall) },
                        trailingContent = {
                            Checkbox(checked = selected, onCheckedChange = { checked ->
                                runProtected {
                                    if (selectedList == 0) {
                                        SleepMode.setWhitelisted(context, app.packageName, checked)
                                        if (checked) { if (app.packageName !in white) white.add(app.packageName) }
                                        else white.remove(app.packageName)
                                    } else {
                                        SleepMode.setBlacklisted(context, app.packageName, checked)
                                        if (checked) { if (app.packageName !in black) black.add(app.packageName) }
                                        else black.remove(app.packageName)
                                    }
                                }
                            })
                        }
                    )
                    HorizontalDivider()
                }
            }
            item {
                Text(
                    "الأولوية: القائمة السوداء أولًا، ثم البيضاء. عند تفعيل فرض البيضاء تُحظر التطبيقات الجديدة تلقائيًا ما لم تضفها إلى البيضاء. لا يمكن ضمان تعليق تطبيقات النظام التي يمنع Android تعليقها.",
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(top = 12.dp)
                )
            }
        }
    }
    RecoveryGateDialog(gate)
}

@Composable
private fun TimeButton(label: String, minuteOfDay: Int, modifier: Modifier = Modifier, onTime: (Int, Int) -> Unit) {
    val context = LocalContext.current
    val time = LocalTime.of(minuteOfDay / 60, minuteOfDay % 60)
    OutlinedButton(
        onClick = {
            TimePickerDialog(context, { _, hour, minute -> onTime(hour, minute) }, time.hour, time.minute, true).show()
        },
        modifier = modifier
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(label)
            Text(String.format("%02d:%02d", time.hour, time.minute), style = MaterialTheme.typography.titleMedium)
        }
    }
}
