package io.github.warleysr.dechainer.activities

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.filled.AppBlocking
import androidx.compose.material.icons.outlined.Block
import androidx.compose.material.icons.outlined.LockClock
import androidx.compose.material.icons.outlined.Logout
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import io.github.warleysr.dechainer.R
import io.github.warleysr.dechainer.data.UsageWarningSettings
import io.github.warleysr.dechainer.screens.setup.SetupDeviceOwnerPrivileges
import io.github.warleysr.dechainer.screens.setup.SetupRecovery
import io.github.warleysr.dechainer.screens.tabs.*
import io.github.warleysr.dechainer.security.SecurityManager
import io.github.warleysr.dechainer.ui.theme.DechainerTheme
import io.github.warleysr.dechainer.viewmodels.DeviceOwnerViewModel
import io.github.warleysr.dechainer.viewmodels.NavigationViewModel
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {

    private val authenticated = mutableStateOf(false)

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (SecurityManager.consumeDebugAutoStartSession(this)) authenticated.value = true
        SecurityManager.consumeDebugRestoreUnknownSourcesRestriction(this)
        enableEdgeToEdge()
        setContent {
            DechainerTheme {
                val viewModel: DeviceOwnerViewModel = viewModel()
                viewModel.addShizukuListener()
                val navViewModel: NavigationViewModel = viewModel()

                val currentScreen = navViewModel.selectedTab()
                val isRoot = currentScreen in listOf("restrictions", "apps", "config")

                BackHandler(enabled = !isRoot) {
                    navViewModel.goBack()
                }

                var currentTime by remember { mutableLongStateOf(System.currentTimeMillis()) }
                LaunchedEffect(Unit) {
                    while (true) {
                        currentTime = System.currentTimeMillis()
                        delay(1000)
                    }
                }

                val context = LocalContext.current
                val notificationPermissionLauncher = rememberLauncherForActivityResult(
                    ActivityResultContracts.RequestPermission()
                ) {}
                LaunchedEffect(authenticated.value) {
                    if (!authenticated.value) return@LaunchedEffect
                    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return@LaunchedEffect

                    val warningPrefs = context.getSharedPreferences(UsageWarningSettings.PREFS_NAME, Context.MODE_PRIVATE)
                    val warningEnabled = warningPrefs.getBoolean(
                        UsageWarningSettings.KEY_ENABLED, UsageWarningSettings.DEFAULT_ENABLED
                    )
                    if (!warningEnabled) return@LaunchedEffect

                    val granted = ContextCompat.checkSelfPermission(
                        context, Manifest.permission.POST_NOTIFICATIONS
                    ) == PackageManager.PERMISSION_GRANTED
                    if (!granted) {
                        notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    topBar = {
                        TopAppBar(
                            title = { Text(stringResource(R.string.app_name)) },
                            navigationIcon = {
                                if (!isRoot) {
                                    IconButton(onClick = { navViewModel.goBack() }) {
                                        Icon(Icons.AutoMirrored.Outlined.ArrowBack, null)
                                    }
                                }
                            },
                            actions = {
                                if (SecurityManager.isSessionActive()) {
                                    val remaining = SecurityManager.sessionEndTime - currentTime
                                    val minutes = (remaining / 1000) / 60
                                    val seconds = (remaining / 1000) % 60
                                    
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Outlined.LockClock, null, modifier = Modifier.padding(end = 4.dp))
                                        Text(
                                            text = "%02d:%02d".format(minutes, seconds),
                                            style = MaterialTheme.typography.labelLarge
                                        )
                                        IconButton(onClick = { SecurityManager.renewSession() }) {
                                            Icon(Icons.Outlined.Refresh, stringResource(R.string.renew_session))
                                        }
                                        IconButton(onClick = { SecurityManager.endSession() }) {
                                            Icon(Icons.Outlined.Logout, null)
                                        }
                                    }
                                }
                            }
                        )
                    },
                    bottomBar = {
                        if (!SecurityManager.isRecoveryCodeSet(this) || !authenticated.value) return@Scaffold

                        val tabs = listOf(
                            Pair("restrictions", stringResource(R.string.restrictions)),
                            Pair("apps", stringResource(R.string.apps)),
                            Pair("config", stringResource(R.string.config))
                        )

                        val selectedBaseTab = when (currentScreen) {
                            "restrictions" -> "restrictions"
                            "apps" -> "apps"
                            "config", "setup_device_owner", "activity_blocker", "browser_restrictions", "blocked_words", "visual_blocking", "impulse_lock", "focus_mode", "usage_warning", "color_filters", "sleep_mode" -> "config"
                            else -> "restrictions"
                        }

                        NavigationBar {
                            tabs.forEach { pair ->
                                NavigationBarItem(
                                    selected = selectedBaseTab == pair.first,
                                    onClick = { navViewModel.navigateTo(pair.first) },
                                    label = { Text(pair.second) },
                                    icon = {
                                        Icon(
                                            when (pair.first) {
                                                "restrictions" -> Icons.Outlined.Block
                                                "apps" -> Icons.Default.AppBlocking
                                                else -> Icons.Outlined.Settings
                                            }, contentDescription = null
                                        )
                                    }
                                )
                            }
                        }
                    }
                ) { innerPadding ->

                    if (!(SecurityManager.isRecoveryCodeSet(this)))
                        SetupRecovery(innerPadding)
                    else {
                        if (!authenticated.value)
                            Box(
                                modifier = Modifier
                                    .padding(innerPadding)
                                    .consumeWindowInsets(innerPadding)
                            ) {
                                LockScreen(onAuthenticated = { authenticated.value = true })
                            }
                        else
                            Box(modifier = Modifier.padding(innerPadding)) {
                                when (currentScreen) {
                                    "restrictions" -> RestrictionsTab()
                                    "apps" -> AppsTab()
                                    "config" -> ConfigTab()
                                    "setup_device_owner" -> SetupDeviceOwnerPrivileges()
                                    "activity_blocker" -> ActivityBlockerScreen()
                                    "browser_restrictions" -> BrowserRestrictionsScreen()
                                    "blocked_words" -> BlockedWordsScreen()
                                    "visual_blocking" -> VisualBlockingScreen()
                                    "impulse_lock" -> ImpulseLockScreen()
                                    "focus_mode" -> FocusModeScreen()
                                    "sleep_mode" -> SleepModeScreen()
                                    "usage_warning" -> UsageWarningScreen()
                                    "color_filters" -> ColorFilterScreen()
                                }
                            }
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        SecurityManager.endSession()
    }
}
